$(document).ready(function()
{
  $("button").live("click dblclick",chk);
  $("#btn1").click(createnwebtn);
});

function chk()
{
alert("Bind Method");
}

function createnwebtn()
{
    //create the element
  var newbtn=$(document.createElement("button"));
  //set all the needed properties
  newbtn.attr("height",20);
   newbtn.attr("width",50);
   newbtn.text("New");
   //place the element in the page
  $("#d1").append(newbtn);

}