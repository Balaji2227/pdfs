window.onload=function()
{
    document.getElementById("btn1").onclick=myFunction;
}

// 1. create an object using Object
// doesnt support reusability
var emp=new Object();
emp.id=111;
emp.name="aaa";
emp.disp=function()
{
    alert(emp.id +emp.name);
}

//2. create object using Literal Notation
// doesnt support reusability
var person={
    id:111,
    name:'aaaa',
    disp:function()
    {
        alert(this.id + this.name);
    }
}
//3. crate object using constructor function notation
//constructor function, no reusability
function Trainee()
{
  this.id=3456;
  this.name="Raam";
  this.disp= function()
  {
      alert(this.id+this.name);

  }
}
// 4. Constructor function with prototyping
function Developer(){}
Developer.prototype.dev_id=111;
Developer.prototype.dev_name="aaaa";
Developer.prototype.disp=function()
{
    alert(this.dev_id+this.dev_name);
}




//procedural function
function myFunction()
{
// var tr= new Trainee();
// var tr2= new Trainee();
 //tr.disp();
 //alert(tr.hasOwnProperty("id"));

 var dev1= new Developer();
 dev1.disp();
  alert(dev1.hasOwnProperty("dev_id"));
}