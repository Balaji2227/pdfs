select * from presidents
----1st method in SQl Server 2008

--3rd method cursor SQl Server 2008
declare c cursor for select president,ROW_NUMBER() over(order by presidentnumber) from Presidents
declare @c1 varchar(40),@c2 int
declare @r int
open c
fetch next from c into @c1,@c2
while @@FETCH_STATUS=0
begin
  if(@c2>=5 and @c2<=10)
 begin
 select * from presidents where  president=@c1
 end
 fetch next from c into @c1,@c2
 end
 close c
 deallocate c


 -- it is made easy in 
 select * from emp order by empid offset 4 rows fetch next 6 rows only;
 with q1(president,no) as (select President,ROW_NUMBER() over(order by presidentnumber) from presidents)
select * from q1 where no >=5 and no<=10
--2nd method SQl Server 2008
select * from(select President,ROW_NUMBER() over(order by presidentnumber) as no from presidents) as t where  t.no>=5 and t.no<=10