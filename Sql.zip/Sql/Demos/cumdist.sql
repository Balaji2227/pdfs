;With Count_CTE AS
(
	Select BelongsTo ,N = COUNT(BelongsTo)	
	From PlayerTable
	Group By BelongsTo
)
,Rank_CTE AS
(
	Select 
		SerialNumber = ROW_NUMBER() OVER(Order By GETDATE())
		,PlayerID
		,PlayerName
		,BelongsTo
		,Amount
		,R = Rank() Over(Partition By BelongsTo Order by BelongsTo,PlayerID,Amount) 
		-- OR 
		-- R = ROW_NUMBER() Over(Partition By BelongsTo Order by BelongsTo,PlayerID,Amount) 
	From PlayerTable
)
Select r.*,c.N, CumilativeDistribution = CAST((r.R)  AS DECIMAL(10,2)) / CAST((c.N ) AS DECIMAL(10,2))
From Rank_CTE r
Join Count_CTE c On r.BelongsTo = c.BelongsTo

