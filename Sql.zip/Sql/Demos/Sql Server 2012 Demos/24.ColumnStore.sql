/* 
	What's New in SQL Server "Denali"?
	Aaron Bertrand - abertrand@sqlsentry.net
*/     

/* DEMO */
-- turn on execution plans and compare

SELECT MAX(SalesAmount), MAX(Freight), MIN(OrderDate)
 FROM FactResellerSales;

CREATE COLUMNSTORE INDEX cs_x 
  ON dbo.FactResellerSales(OrderDate, SalesAmount, TaxAmt, Freight, TotalProductCost);

SELECT MAX(SalesAmount), MAX(Freight), MIN(OrderDate)
 FROM FactResellerSales;

DROP INDEX dbo.FactResellerSales.cs_x;
GO


-- example 2

SELECT SalesTerritoryKey, 
	SUM(ExtendedAmount) AS SalesByTerritory
FROM FactResellerSales
GROUP BY SalesTerritoryKey
ORDER BY SalesTerritoryKey;

-- already have a big ColumnStore index on _copy

SELECT SalesTerritoryKey, 
	SUM(ExtendedAmount) AS SalesByTerritory
FROM FactResellerSales_Copy
GROUP BY SalesTerritoryKey
ORDER BY SalesTerritoryKey;
