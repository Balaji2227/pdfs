/* 
	What's New in SQL Server "Denali"?
	Aaron Bertrand - abertrand@sqlsentry.net
*/     

/* DEMO */

DECLARE @d DATE = '2011-11-13';

SELECT
	FORMAT(@d, N'yyyy-MM'),
	FORMAT(@d, N'yyyy-MM-dd'),
	FORMAT(@d, N'yyyy-MMM'),
	FORMAT(@d, N'yyyy-MMM')
UNION
SELECT
	FORMAT(@d, N'dddd, MMM dd, yyyy'),
	FORMAT(@d, N'dddd, MMMM dd, yyyy'),
	FORMAT(@d, N'dddd, MMMM dd, yyyy', N'fr-fr'),
	FORMAT(@d, N'dddd, MMMM dd, yyyy', N'ja-jp');

DECLARE
    @m DECIMAL(12,2) = 1271627.13;

SELECT 
	FORMAT(@m, N'C', N'de-de'),
	FORMAT(@m, N'C', N'en-gb'),
	FORMAT(@m, N'C', N'en-us'),
	FORMAT(@m, N'C', N'fr-fr'),
	FORMAT(@m, N'C', N'ja-jp'),
	FORMAT(@m, N'00000000000');

SELECT 
	TRY_CONVERT(DATETIME, '2011-10-12'),
	TRY_CONVERT(DATETIME, '3/4-99999'),
	TRY_CONVERT(INT, 355),
	TRY_CONVERT(INT, 'zzz');

SELECT
	TRY_PARSE('13/11/2011' AS DATETIME USING N'en-gb'),
	TRY_PARSE('13/11/2011' AS DATETIME USING N'en-us'),
	TRY_PARSE('3/4-99999'  AS DATETIME);

SELECT PARSE('13/11/2011' AS DATETIME USING N'en-gb');

SELECT PARSE('13/11/2011' AS DATETIME USING N'en-us');

SELECT PARSE('3/4-99999'  AS DATETIME);