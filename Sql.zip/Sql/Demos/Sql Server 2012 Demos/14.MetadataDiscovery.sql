/* 
	What's New in SQL Server "Denali"?
	Aaron Bertrand - abertrand@sqlsentry.net
*/     

/* DEMO 1 */
/* What is wrong with FMTONLY? */

SET FMTONLY ON;
GO

IF (1=2)
	SELECT * FROM sys.indexes;
ELSE
	SELECT * FROM sys.sql_modules;

SET FMTONLY OFF;


SET FMTONLY ON;

IF (1=2)
	SET FMTONLY OFF;

SELECT * FROM sys.indexes;

SET FMTONLY OFF;


/* DEMO 2 */
/* metadata discovery of SELSTAR queries */

CREATE TABLE dbo.x
(
	foo     INT PRIMARY KEY,
	bar     DECIMAL(12, 2),
	splunge NVARCHAR(MAX),
	blat	SYSNAME,
	active  BIT,
	whence  DATETIME2(4) NOT NULL DEFAULT SYSDATETIME()
);

SELECT 
	c.name, 
	user_type_name = t.name, 
	system_type_name = s.name, 
	c.[precision], 
	c.scale, 
	c.max_length
FROM sys.columns AS c
LEFT OUTER JOIN sys.types AS t
ON c.user_type_id = t.user_type_id
LEFT OUTER JOIN sys.types AS s
ON c.system_type_id = s.system_type_id
AND c.system_type_id <> c.user_type_id
WHERE [object_id] = OBJECT_ID('dbo.x')
AND t.name <> COALESCE(s.name, '')
ORDER BY column_id;

SELECT name, user_type_name, system_type_name, is_nullable
FROM sys.dm_exec_describe_first_result_set
(
	N'SELECT * FROM dbo.x;',
	NULL,
	0
)
ORDER BY column_ordinal;

DROP TABLE dbo.x;
GO


/* DEMO 3 */
/* metadata discovery to support building staging tables */

SET NOCOUNT ON;

SELECT 'CREATE TABLE dbo.DMVStats(';

SELECT 
	CASE column_ordinal 
		WHEN 1 THEN '' ELSE ',' END 
	+ name + ' ' + system_type_name + CASE is_nullable 
		WHEN 0 THEN ' not null' ELSE '' END
FROM 
	sys.dm_exec_describe_first_result_set
	(
		N'SELECT * FROM sys.dm_exec_sessions;',
		NULL,
		0
	)
ORDER BY column_ordinal;

SELECT ');'

GO

/* DEMO 4 */
/* it does not work for batches with #temp tables */

EXEC sys.sp_describe_first_result_set N'DECLARE @x TABLE(i INT);SELECT i FROM @x;';
EXEC sys.sp_describe_first_result_set N'CREATE TABLE #y (j INT);SELECT j FROM #y;';
GO


/* DEMO 5 */
/* sniffing of undeclared parameters */

EXEC sys.sp_describe_undeclared_parameters
	@tsql = N'SELECT * FROM sys.objects 
		WHERE [object_id] = @ObjectID
		OR (name LIKE @ObjectName);';

EXEC sys.sp_describe_undeclared_parameters
	@tsql = N'SELECT *, @x FROM sys.objects';



/* other interesting stuff */

CREATE TABLE dbo.a(a INT NULL,     b VARCHAR(10),  c  INT,      d  INT);
CREATE TABLE dbo.b(a INT NOT NULL, b VARCHAR(255), c  DATETIME, d2 INT);

EXEC sp_describe_first_result_set @tsql = N'IF (1=2)
		SELECT a,b FROM dbo.a; 
	ELSE
		SELECT a,b FROM dbo.b;';

EXEC sp_describe_first_result_set @tsql = N'IF (1=2)
		SELECT a,b,c FROM dbo.a; 
	ELSE
		SELECT a,b,c FROM dbo.b;';

EXEC sp_describe_first_result_set @tsql = N'IF (1=2)
		SELECT a,b,c,d FROM dbo.a; 
	ELSE
		SELECT a,b,c,d2 FROM dbo.b;';

DROP TABLE dbo.a, dbo.b;
