/* 
	What's New in SQL Server "Denali"?
	Aaron Bertrand - abertrand@sqlsentry.net
*/         

/* DEMO 1 */
/* hard-coded offset & page size */

SELECT
	[object_id], 
	name
FROM
	sys.all_objects
ORDER BY
	name
OFFSET 
	10 ROWS
FETCH NEXT
	10 ROWS ONLY;

GO

/* DEMO 2 */
/* pass in page number & page size */

DECLARE 
	@PageNumber INT = 2,
	@PerPage    INT = 10;

SELECT 
	[object_id], 
	name
FROM
	sys.all_objects
ORDER BY
	name
OFFSET 
	(@PageNumber - 1) * @PerPage ROWS
FETCH NEXT
	@PerPage ROWS ONLY;
