-- example 1

;WITH d([Month],OrderCount) AS 
(
	SELECT DATEDIFF(MONTH, '19000101', OrderDate), COUNT(*) 
	FROM dbo.FactResellerSales
	GROUP BY DATEDIFF(MONTH, '19000101', OrderDate)
)
SELECT 
	[Month] = DATEADD(MONTH, [Month], '19000101'),
	OrderCount, 
	SameMonthPreviousYear = LAG(OrderCount, 12, 0) OVER (ORDER BY [Month])
FROM d
ORDER BY [Month];

-- old way is slightly more convoluted

;WITH d([Month],OrderCount) AS 
(
	SELECT DATEDIFF(MONTH, '19000101', OrderDate), COUNT(*) 
	FROM dbo.FactResellerSales
	GROUP BY DATEDIFF(MONTH, '19000101', OrderDate)
)
SELECT 
	[Month] = DATEADD(MONTH, d.[Month], '19000101'),
	d.OrderCount, 
	SameMonthPreviousYear = l.OrderCount
FROM d 
LEFT OUTER JOIN d AS l
ON DATEADD(MONTH, d.[Month]-12, '19000101') = DATEADD(MONTH, l.[Month], '19000101')
ORDER BY d.[Month];





-- example 2



DECLARE @d DATETIME2 = CURRENT_TIMESTAMP, @i INT = 50;

SELECT TOP (@i)
	rs.ProductKey,
	rs.OrderDateKey,
	rs.SalesOrderNumber,
	DaysSincePreviousOrder = rs.OrderDateKey - 
	(
		SELECT TOP(1) prev.OrderDateKey
            FROM dbo.FactResellerSales AS prev
            WHERE rs.ProductKey = prev.ProductKey
            AND prev.OrderDateKey <= rs.OrderDateKey
            AND prev.SalesOrderNumber < rs.SalesOrderNumber
            ORDER BY prev.OrderDateKey DESC,
                    prev.SalesOrderNumber DESC
	)
FROM dbo.FactResellerSales AS rs
ORDER BY rs.ProductKey, rs.OrderDateKey, rs.SalesOrderNumber;

SELECT DATEDIFF(MILLISECOND, @d, CURRENT_TIMESTAMP); 
SET @d = CURRENT_TIMESTAMP;

SELECT TOP (@i)
	ProductKey, 
	OrderDateKey, 
	SalesOrderNumber,
	DaysSincePreviousOrder = OrderDateKey - LAG(OrderDateKey)
		OVER (PARTITION BY ProductKey ORDER BY OrderDateKey, SalesOrderNumber)
FROM dbo.FactResellerSales AS rs
ORDER BY ProductKey, OrderDateKey, SalesOrderNumber;

SELECT DATEDIFF(MILLISECOND, @d, CURRENT_TIMESTAMP); 


