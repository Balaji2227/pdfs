/* 
	What's New in SQL Server "Denali"?
	Aaron Bertrand - abertrand@sqlsentry.net
*/     

/* DEMO */
/* contained databases */


/* need to turn configuration options on */

EXEC sp_configure 'show advanced options', 1;
GO
RECONFIGURE WITH OVERRIDE;
GO
EXEC sp_configure 'contained database authentication', 1;
GO
EXEC sp_configure 'show advanced options', 0;
GO
RECONFIGURE WITH OVERRIDE;
GO


/* create databases with non-server collation */

CREATE DATABASE NonContained COLLATE SQL_Latin1_General_CP437_BIN;
GO

CREATE DATABASE Contained    COLLATE SQL_Latin1_General_CP437_BIN;
GO
ALTER DATABASE  Contained    SET CONTAINMENT = PARTIAL;
GO


/* create user with password in a contained database */

USE [Contained];
GO
CREATE USER contained_user WITH PASSWORD = 'foo';
GO

/* no rows */
SELECT * FROM sys.server_principals   WHERE name LIKE 'contained%';

/* user is only at database level */
SELECT * FROM sys.database_principals WHERE name LIKE 'contained%';


/* show collation behavior against typical db */

USE NonContained;
GO
CREATE TABLE dbo.foo(bar VARCHAR(32));
GO
INSERT dbo.foo SELECT 'foo' UNION SELECT 'bar';
GO
CREATE TABLE #foo(bar VARCHAR(32));
INSERT #foo SELECT 'foo';

/* error 468 here */
SELECT f.bar
	FROM dbo.foo AS f 
	INNER JOIN #foo AS t 
	ON f.bar = t.bar;
GO
DROP TABLE #foo;
GO

/* repeat against contained database */
USE Contained;
GO
CREATE TABLE dbo.foo(bar VARCHAR(32));
GO
INSERT dbo.foo SELECT 'foo' UNION SELECT 'bar';
GO
CREATE TABLE #foo(bar VARCHAR(32));
INSERT #foo SELECT 'foo';

SELECT f.bar
	FROM dbo.foo AS f 
	INNER JOIN #foo AS t 
	ON f.bar = t.bar;
GO
DROP TABLE #foo;
GO



/* show DMV */

USE Contained;
GO

CREATE PROCEDURE dbo.get_foo
AS
	SELECT [object_id], name
		FROM NonContained.sys.objects;

	SELECT * FROM dbo.foo;

	SELECT * FROM fake_db.dbo.objects;
GO

SELECT
	[name] = OBJECT_NAME(major_id),
	[statement] = SUBSTRING
		(
			m.[definition],
			(e.statement_offset_begin+2)/2,
			CASE 
				WHEN e.statement_offset_end = -1 
					THEN DATALENGTH(m.[definition])
				ELSE
					(e.statement_offset_end - e.statement_offset_begin+2)/2 
				END
		)
	FROM sys.dm_db_uncontained_entities AS e 
	INNER JOIN sys.sql_modules AS m
	ON e.major_id = m.[object_id];
GO

USE [master];
GO
DROP DATABASE Contained, NonContained;
GO