/* 
	What's New in SQL Server "Denali"?
	Aaron Bertrand - abertrand@sqlsentry.net
*/     

/* DEMO 1 */
/* basic THROW usage */

THROW 66666, 'Something bad happened.', 255;
GO

-- unlike RAISERROR, < 50000 is not valid:
THROW 49999, 'Something bad happened.', 255;
GO


/* DEMO 2 */
/* re-raise */

SET NOCOUNT ON;

BEGIN TRY
	SELECT 1/0;
END TRY
BEGIN CATCH
	PRINT 'Hi from catch.';
	THROW;
	-- for RAISERROR, you'd have to construct the message yourself
END CATCH;