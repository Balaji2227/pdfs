/* 
	What's New in SQL Server "Denali"?
	Aaron Bertrand - abertrand@sqlsentry.net
*/     

/* DEMO */

-- IIF - just shorthand for *simple* CASE expressions

SELECT 
	a = IIF(1=1, 'foo', 'bar'),
	b = IIF(1=2, 'foo', 'bar');

-- CHOOSE - ordinal-based selection

SELECT
	a = CHOOSE(1, 'foo', 'bar', 'blat'),
	b = CHOOSE(3, 'foo', 'bar', 'blat');

-- CONCAT - not *group* concat

SELECT
	a = CONCAT('foo', 'bar', NULL, 1, NULL, GETDATE()),
	b = CONCAT('FirstName', CHAR(39), ',' + NULL, ' LastName');

-- EOMONTH

SELECT
	[End of this month] = EOMONTH(GETDATE()),
	[End of this month last year] 
	= EOMONTH(GETDATE(), -12);