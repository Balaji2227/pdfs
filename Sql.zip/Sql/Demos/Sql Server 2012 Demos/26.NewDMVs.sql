/* 
	What's New in SQL Server "Denali"?
	Aaron Bertrand - abertrand@sqlsentry.net
*/     

/* DEMO */
/* sys.dm_os_volume_stats */

SELECT    
	vs.volume_mount_point, -- e.g. C:\   
	drive_size_MB = vs.total_bytes/1024/1024,
	drive_free_space_MB = vs.available_bytes/1024/1024,    
	drive_percent_free = CONVERT(DECIMAL(5,2), vs.available_bytes * 100.0 / vs.total_bytes),
	file_size_MB = f.[size] / 128,   
	[database] = DB_NAME(f.[database_id]),    
	[file_name] = f.[name],   
	[file_path] = f.physical_name
FROM
    sys.master_files AS f 
	CROSS APPLY sys.dm_os_volume_stats(f.[database_id], f.[file_id]) AS vs
WHERE f.[database_id] < 32767
ORDER BY
	file_size_MB DESC;


/* sys.dm_os_windows_info */
/* 28 = Win 7 Ultimate N */

SELECT
	windows_release,
	windows_service_pack_level,
	windows_sku,
	os_language_version
FROM
    sys.dm_os_windows_info;


/* sys.dm_server_registry */

SELECT
    registry_key,
	value_name,   
	value_data
FROM
    sys.dm_server_registry;


/* sys.dm_server_services */

SELECT
	servicename,
	[startup] = startup_type_desc,
	[status] = status_desc,
	pid = process_id,
	last_startup_time,
	service_account,
	[clustered] = is_clustered,
	cluster_nodename
FROM
    sys.dm_server_services;


/* sys.dm_os_sys_info */

SELECT
	virtual_machine_type,
	virtual_machine_type_desc
FROM
	sys.dm_os_sys_info;


/* sys.sp_server_diagnostics */

EXEC sys.sp_server_diagnostics
	WITH RESULT SETS
	(
		(
			ct   DATETIME,
			area SYSNAME,
			st   INT,
			sd   VARCHAR(32),
			data XML
		)
	);















/* sys.dm_exec_query_stats */

SELECT
	[statement] = CASE 
		WHEN qs.statement_start_offset > 0 THEN
			SUBSTRING
			(
				t.[text],
				(qs.statement_start_offset+2)/2,
				CASE
					WHEN qs.statement_end_offset = -1 
						THEN DATALENGTH(t.[text])
					ELSE 
						(qs.statement_end_offset-qs.statement_start_offset+2)/2 
					END
			)
		ELSE t.[text] END,	
	avg_rows = (qs.total_rows/qs.execution_count),
	qs.last_rows,
	qs.min_rows,
	qs.max_rows,
	qs.execution_count,
	qs.max_elapsed_time
FROM
	sys.dm_exec_query_stats AS qs
CROSS APPLY
	sys.dm_exec_sql_text(qs.[sql_handle]) AS t
ORDER BY
	qs.max_elapsed_time DESC;
