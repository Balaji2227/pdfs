/* 
	What's New in SQL Server "Denali"?
	Aaron Bertrand - abertrand@sqlsentry.net
*/     

/* DEMO */
/* sys.sp_server_diagnostics */

EXEC sys.sp_server_diagnostics --@repeat_interval = 5
	WITH RESULT SETS
	(
		(
			ct   DATETIME,
			area SYSNAME,
			st   INT,
			sd   VARCHAR(32),
			data XML
		)
	);















/*
Msg 11535, Level 16, State 1, Procedure sp_server_diagnostics, Line 1
EXECUTE statement failed because its WITH RESULT SETS clause specified 2 result set(s), and the statement tried to send more result sets than this.
*/

