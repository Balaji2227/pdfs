/* 
	What's New in SQL Server "Denali"?
	Aaron Bertrand - abertrand@sqlsentry.net
*/     

/* DEMO */
/*  tab strip / zoom
	IntelliSense / region / clipboard / snippets
	restore operations       */

SELECT * FROM sys.wait

INSERT INTO 1,'2011-01-01','a@foo.com 22
INSERT INTO 2,'2010-02-05','b@bar.com 35
INSERT INTO 3,'2009-06-08','c@bla.com 12

SELECT * FROM sys



PRINT 'foo';































-- long script...

dfndskfnds