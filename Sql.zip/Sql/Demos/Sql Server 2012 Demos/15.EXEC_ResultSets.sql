/* 
	What's New in SQL Server "Denali"?
	Aaron Bertrand - abertrand@sqlsentry.net
*/          

/* DEMO 1 */
/* force a data type without explicit conversion */

EXEC(N'SELECT a = 2; SELECT b = 1')
WITH RESULT SETS
(
	(a TINYINT),
	(b BIT)
);
GO


/* DEMO 2 */
/* rename columns */
/* different apps can adapt to schema changes at different rates */

EXEC [master].dbo.sp_who2
WITH RESULT SETS
(
	(
		[SPID]         INT,          -- <-- fixed the data type
		[Status]       NVARCHAR(32),
		[Login]        SYSNAME,
		HostName       SYSNAME,
		Blocker	       CHAR(5),      -- <-- renamed this column
		[Database]     SYSNAME,
		Command        NVARCHAR(32),
		CPUTime        VARCHAR(30),
		DiskIO         VARCHAR(30),
		LastBatch      VARCHAR(48),
		ProgramName    NVARCHAR(255),
		Redundant_SPID CHAR(5),      -- <-- renamed this column
		RequestID      INT
	)
);
GO


/* DEMO 3 */
/* OBJECT_DEFINITION with more usable output */

EXEC('SELECT 
	name,
	OBJECT_DEFINITION([object_id])
FROM sys.procedures
WHERE name LIKE ''foo%'';');

EXEC('SELECT 
	name,
	OBJECT_DEFINITION([object_id])
FROM sys.procedures
WHERE name LIKE ''foo%'';')
WITH RESULT SETS
(
	(
		name SYSNAME,
		body XML
	)
);
