/* 
	What's New in SQL Server "Denali"?
	Aaron Bertrand - abertrand@sqlsentry.net
*/     

/* DEMO */
/* 
	FORCESEEK / FORCESCAN 
	This will currently only run on 2008 R2 SP1 (CTP or RTM)
	It should work in Denali CTP3 and up
*/

USE tempdb;
GO

IF OBJECT_ID('dbo.foo', 'U') IS NOT NULL
	DROP TABLE dbo.foo;
GO

CREATE TABLE [dbo].[foo]
(
	[a] [int] NOT NULL,
	[b] [int],
	[c] [int],
	[d] [int],
	CONSTRAINT PK PRIMARY KEY (a)
);
GO
CREATE NONCLUSTERED INDEX [x] ON [dbo].[foo]([b] ASC);
CREATE NONCLUSTERED INDEX [y] ON [dbo].[foo]([b] ASC) INCLUDE([a]);
GO

-- turn on execution plan to see how these work

-- uses a seek against PK
SELECT [a],[b] FROM [dbo].[foo]
 WHERE [a] = 1 AND [b] = 2;

-- existing method to force a seek
-- in this case the PK is still the subject of the seek
SELECT [a],[b] FROM [dbo].[foo] WITH (FORCESEEK)
 WHERE [a] = 1 AND [b] = 2;

-- if we want to force a different index, name it!
SELECT [a],[b] FROM [dbo].[foo] WITH (FORCESEEK(x(b)))
 WHERE [a] = 1 AND [b] = 2;

-- and if we want to force a scanm we can
SELECT [a],[b] FROM [dbo].[foo] WITH (FORCESCAN)
 WHERE [a] = 1 AND [b] = 2;