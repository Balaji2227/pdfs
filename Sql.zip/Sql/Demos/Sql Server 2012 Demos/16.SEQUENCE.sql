/* 
	What's New in SQL Server "Denali"?
	Aaron Bertrand - abertrand@sqlsentry.net
*/       

/* DEMO 1 */
/* basic sequence usage */

CREATE SEQUENCE dbo.MySequence
	AS INT
	MINVALUE 1
	NO MAXVALUE
	START WITH 1;

CREATE TABLE dbo.Customers
(
	CustomerID INT PRIMARY KEY,
	EMail	   VARCHAR(320) NOT NULL UNIQUE
);

CREATE TABLE dbo.Orders
(
	OrderID    INT PRIMARY KEY,
	CustomerID INT NOT NULL FOREIGN KEY
			   REFERENCES dbo.Customers(CustomerID)
);

DECLARE 
	@CustomerID INT = NEXT VALUE FOR dbo.MySequence,
	@OrderID    INT = NEXT VALUE FOR dbo.MySequence;

INSERT dbo.Customers(CustomerID, EMail)
	SELECT @CustomerID, 'aaron@foo.com';

INSERT dbo.Orders(OrderID, CustomerID)
	SELECT @OrderID, @CustomerID;

SELECT * FROM dbo.Customers;
SELECT * FROM dbo.Orders;
GO

DROP TABLE dbo.Orders, dbo.Customers;
GO


/* DEMO 2 */
/* grab a block of values */

DECLARE 
	@fv SQL_VARIANT, 
	@lv SQL_VARIANT;

EXEC sys.sp_sequence_get_range 
	@sequence_name     = 'dbo.MySequence',
	@range_size        = 40,
	@range_first_value = @fv OUTPUT,
	@range_last_value  = @lv OUTPUT;

SELECT
	[first] = CONVERT(INT, @fv),
	[last]  = CONVERT(INT, @lv),
	[next]  = NEXT VALUE FOR dbo.MySequence;

GO
DROP SEQUENCE dbo.MySequence;
GO