--SQL Server 2008
BEGIN TRY
     SELECT 1/0
END TRY
BEGIN CATCH
     DECLARE @ErrorNumber int
     DECLARE @ErrorState int
     DECLARE @ErrorSeverity int
     DECLARE @ErrorLine int
     DECLARE @ErrorProcedure NVARCHAR(MAX)  
     DECLARE @ErrorMessage NVARCHAR(MAX)  
     DECLARE @UserName NVARCHAR(256)  
     DECLARE @HostName NVARCHAR(128)
	SELECT @ErrorNumber = ERROR_NUMBER ()  
     ,@ErrorState = ERROR_STATE()  
     ,@ErrorSeverity = ERROR_SEVERITY()  
     ,@ErrorLine = ERROR_LINE()  
     ,@ErrorProcedure = ERROR_PROCEDURE()  
     ,@ErrorMessage = ERROR_MESSAGE()  
     ,@UserName = SUSER_SNAME()  
     ,@HostName = Host_NAME()  
	SELECT @ErrorNumber,@ErrorState,@ErrorSeverity,@ErrorLine,@ErrorProcedure,@ErrorMessage,@UserName,@HostName
   
     RAISERROR (@ErrorMessage, @ErrorSeverity, 1 )
END CATCH



--Sql server 2012

BEGIN TRY
   SELECT 1/0;
END TRY
BEGIN CATCH
    THROW;
END CATCH
